
<?php
error_reporting(E_All);
if(empty($summary_rep_data)) {
    echo "<script type='text/javascript'>
        alert('Unauthorized Access. Get Outta Here!');
        window.top.close();  //close the current tab
      </script>";
} else {
    $html = ''; //set html to blank
    $clientID = "";
    if(!empty($summary_rep_data)) {
        $clientID = $summary_rep_data[0]->client_id;
        $clientName = $summary_rep_data[0]->client_name;
    } else {
        $clientID = "";
        $clientName = "";
    }
    $css = '<style type="text/css">
                table { width:100% }
                table td {font-size: 12px; padding:2px; text-align:center; }
                table th {font-size: 12px; padding:2px; text-align:center; border: 1px solid #4d4d4d;}
                .border {border: 1px solid #4d4d4d;}
                .amount { text-align:right; text-indent: 15px; }
                .noWrap { white-space: nowrap; }
                .title { line-height:28px; background-color: #f4a817; color: #000; font-size:15px; font-weight:bold; text-align:center; border:2px double #4d4d4d; }
                .info { font-size: 12px; font-weight: lighter; border:none; }
                .head-row { background-color: #4f8edc; color: #fff; font-weight:bold;}
                .normal {font-weight: normal;}
                .dataTotal {font-weight: bold; color:#4f8edc;}
                .no-border {border-width: 0px; border-color:#fff;}
                .client-name { text-align: left; font-size: 14px; font-weight: bold; }
            </style>';
    $title = '<div class="title row">Summary Report of '.$clientName.'</div>
                    <br/>';
    if($summary_rep_data)
    {
         $htmlVal = '';
        $header = true;
        $content = false;
        $footer = false;
        $clientTotal = 0; //overall amount

        foreach($summary_rep_data as $row)
        {
            $total = round($row->insurance_inv + $row->fixed_deposit + $row->mutual_fund + $row->equity + $row->property + $row->commodity);
            if($header) {
                $htmlVal .= '<table border="0" cellpadding="4" style="text-align:center; border-width:0px;">
                    <tbody>
                        <tr nobr="true" class="head-row">
                            <th width="120">Insurance</th>
                            <th width="120">Fixed Income</th>
                            <th width="120">Mutual Funds</th>
                            <th width="120">Equity</th>
                            <th width="120">Real Estate</th>
                            <th width="120">Commodity</th>
                            <th width="140">Total Portfolio</th>
                            <th width="120">Life Cover</th>
                        </tr>
                    </tbody>
                    <tbody>';
                $header = false;
                $content = true;
            }

            if($content)
            {
                $htmlVal .= '<tr nobr="true">';
                        $ins = intval($row->insurance_inv);
                        $htmlVal .= !empty($ins)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->insurance_inv,0)).'</td>':'<td class="border normal"></td>';
                       // $htmlVal .= !empty($row->insurance_fund)?'<td>'.$this->common_lib->moneyFormatIndia(round($row->insurance_fund,2)).'</td>':'<td></td>';
                        $fd = intval($row->fixed_deposit);
                        $htmlVal .= !empty($fd)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->fixed_deposit,0)).'</td>':'<td class="border normal"></td>';
                        $mf = intval($row->mutual_fund);
                        $htmlVal .= !empty($mf)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->mutual_fund,0)).'</td>':'<td class="border normal"></td>';
                        $eq = intval($row->equity);
                        $htmlVal .= !empty($eq)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->equity,0)).'</td>':'<td class="border normal"></td>';
                        $prop = intval($row->property);
                        $htmlVal .= !empty($prop)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->property,0)).'</td>':'<td class="border normal"></td>';
                        $com = intval($row->commodity);
                        $htmlVal .= !empty($com)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->commodity,0)).'</td>':'<td class="border normal"></td>';

                        $htmlVal .= '<td class="border amount">'.$this->common_lib->moneyFormatIndia(round($total,0)).'</td>';

                        $lc = intval($row->life_cover);
                        $htmlVal .= !empty($lc)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->life_cover,0)).'</td>':'<td class="border normal"></td>';
                    $htmlVal .= '</tr>';
            }
        }
        $htmlVal .= '</tbody>
                </table>';
    }

    $html .= $css;
    $html .= $htmlVal;
}
?>

<div id="page-content" style="margin: 0; margin-top: -54px;" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
 <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.0/Chart.bundle.min.js'></script>
    <div id='wrap'>
        <div id="page-heading">
            <div class="options">
                <div class="btn-toolbar">
                    <div class="btn-group">
                        <a href='#'class="btn btn-default dropdown-toggle" data-toggle='dropdown'><i class="fa fa-cloud-download"></i><span class="hidden-xs"> Export as  </span><span class="caret"></span></a>

                        <ul class="dropdown-menu">
                            <li><a href="#" onclick=";export_to_excel('<?php echo base_url('client/Mutual_funds/export_to_excel');?>');">Excel File (*.xlsx)</a></li>
                            <li><a href="#" onclick="export_to_pdf('<?php echo base_url('client/Mutual_funds/export_to_pdf');?>');">PDF File (*.pdf)</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">

            <form action="#" id="report_form" method="post" class="form-horizontal row-border">
                <div class="panel panel-midnightblue">
                    <div class="panel-gray panel-body collapse in panel-noborder">
                        <div id="css_data"><?php echo $css; ?></div>
                        <div class="rep-logo" style="margin-bottom: 120px;">
                            <?php if(!empty($logo)) { ?>
                                <img src="<?php echo base_url('uploads/brokers/'.$logo);?>" style="float: right; max-height: 80px;" />
                            <?php } ?>
                        </div>
                        <div id="title_data"><?php echo $title; ?></div>
                        <div class="row" id="report_data"  style="overflow-x: auto;">
                          <!-- <div id="chartContainer" style="height:300px;width:600px;">
                      		</div> -->
                          <?php echo $htmlVal; ?>
                        </br></br>
                          <div id="img"></div>
                        <input type="hidden" name="logo" id="logo" value="<?php echo $logo;?>" />
                        <input type="hidden" name="name" id="name" value="<?php echo $clientName;?>" />
                        <input type="hidden" name="titleData" id="titleData" />
                        <input type="hidden" name="htmlData" id="htmlData" />
                        <input type="hidden" name="report_name" id="reportName" value="<?php echo $clientName;?> Summary Report" />
                        </div>
                        <!-- <div id="canvas_div"class="col-md-4 col-sm-12 col-xs-12" style="padding-top:20px">
                         <div class="x_panel tile fixed_height_300">
                           <div class="x_title">
                             <h2 id="switchID">Asset Allocation</h2>
                             <div class="clearfix"></div>
                           </div>
                           <div>
                             <div class="x_content">
                                     <canvas id="myChart" height="200" width="200" style="margin: 15px 10px 10px 0"></canvas>
                             </div>
                           </div>
                         </div>
                       </div> -->
                      </div>
              </div>
            </form>
        </div>
    </div>
</div>
<script>
var canvas, ctx, bMouseIsDown = false, iLastX, iLastY,
    $save, $imgs, $imgW, $imgH,
    $sel;
function init ()
{

      // init();
    canvas = document.getElementById('myChart');
    ctx = canvas.getContext('2d');
    // $save = document.getElementById('save');
    $sel = document.getElementById('sel');
    $imgs = document.getElementById('img');
    $imgW = 300;
    $imgH = 300;
    bind();
    draw();
}
function bind ()
{
    // $('#convert').click(function(e)
    //   {
        var type = 'png',
            w = 400,
            h = 400;
          $imgs.append(Canvas2Image.convertToImage(canvas, w, h, type))
          //$imgs.append("<p>Dipak</p>");
          $('#canvas_div').hide();
    // })

}
function draw () {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 600, 400);
    ctx.fillStyle = 'red';
    ctx.fillRect(100, 100, 50, 50);
}
</script>
<script>

$(document).ready(function()
{
   load_pie_chart();
function load_pie_chart()
{
      Chart.defaults.doughnutLabels = Chart.helpers.clone(Chart.defaults.doughnut);
      var helpers = Chart.helpers;
      var defaults = Chart.defaults;
      Chart.controllers.doughnutLabels = Chart.controllers.doughnut.extend({
      updateElement: function(arc, index, reset) {
        var _this = this;
        var chart = _this.chart,
            chartArea = chart.chartArea,
            opts = chart.options,
            animationOpts = opts.animation,
            arcOpts = opts.elements.arc,
            centerX = (chartArea.left + chartArea.right) / 2,
            centerY = (chartArea.top + chartArea.bottom) / 2,
            startAngle = opts.rotation, // non reset case handled later
            endAngle = opts.rotation, // non reset case handled later
            dataset = _this.getDataset(),
            circumference = reset && animationOpts.animateRotate ? 0 : arc.hidden ? 0 : _this.calculateCircumference(dataset.data[index]) * (opts.circumference / (2.0 * Math.PI)),
            innerRadius = reset && animationOpts.animateScale ? 0 : _this.innerRadius,
            outerRadius = reset && animationOpts.animateScale ? 0 : _this.outerRadius,
            custom = arc.custom || {},
            valueAtIndexOrDefault = helpers.getValueAtIndexOrDefault;

        helpers.extend(arc, {
          // Utility
          _datasetIndex: _this.index,
          _index: index,

          // Desired view properties
          _model: {
            x: centerX + chart.offsetX,
            y: centerY + chart.offsetY,
            startAngle: startAngle,
            endAngle: endAngle,
            circumference: circumference,
            outerRadius: outerRadius,
            innerRadius: innerRadius,
            label: valueAtIndexOrDefault(dataset.label, index, chart.data.labels[index])
          },

          draw: function () {
          	var ctx = this._chart.ctx,
      					vm = this._view,
      					sA = vm.startAngle,
      					eA = vm.endAngle,
      					opts = this._chart.config.options;

      				var labelPos = this.tooltipPosition();
      				var segmentLabel = vm.circumference / opts.circumference * 100;

      				ctx.beginPath();

      				ctx.arc(vm.x, vm.y, vm.outerRadius, sA, eA);
      				ctx.arc(vm.x, vm.y, vm.innerRadius, eA, sA, true);

      				ctx.closePath();
      				ctx.strokeStyle = vm.borderColor;
      				ctx.lineWidth = vm.borderWidth;

      				ctx.fillStyle = vm.backgroundColor;

      				ctx.fill();
      				ctx.lineJoin = 'bevel';

      				if (vm.borderWidth) {
      					ctx.stroke();
      				}

      				if (vm.circumference > 0.15) { // Trying to hide label when it doesn't fit in segment
      					ctx.beginPath();
      					ctx.font = helpers.fontString(opts.defaultFontSize, opts.defaultFontStyle, opts.defaultFontFamily);
      					ctx.fillStyle = "#fff";
      					ctx.textBaseline = "top";
      					ctx.textAlign = "center";

                // Round percentage in a way that it always adds up to 100%
      					ctx.fillText(segmentLabel.toFixed(0) + "%", labelPos.x, labelPos.y);
      				}
          }
        });

        var model = arc._model;
        model.backgroundColor = custom.backgroundColor ? custom.backgroundColor : valueAtIndexOrDefault(dataset.backgroundColor, index, arcOpts.backgroundColor);
        model.hoverBackgroundColor = custom.hoverBackgroundColor ? custom.hoverBackgroundColor : valueAtIndexOrDefault(dataset.hoverBackgroundColor, index, arcOpts.hoverBackgroundColor);
        model.borderWidth = custom.borderWidth ? custom.borderWidth : valueAtIndexOrDefault(dataset.borderWidth, index, arcOpts.borderWidth);
        model.borderColor = custom.borderColor ? custom.borderColor : valueAtIndexOrDefault(dataset.borderColor, index, arcOpts.borderColor);

        // Set correct angles if not resetting
        if (!reset || !animationOpts.animateRotate) {
          if (index === 0) {
            model.startAngle = opts.rotation;
          } else {
            model.startAngle = _this.getMeta().data[index - 1]._model.endAngle;
          }

          model.endAngle = model.startAngle + model.circumference;
        }

        arc.pivot();
      }
      });
      var config = {
      type: 'doughnutLabels',
      data: {
        datasets: [{
          data: [           <?php echo isset($dash_data['varTotalEquityPortfolio'])?intval($dash_data['varTotalEquityPortfolio']):intval(0);?>,
                           <?php echo isset($dash_data['varFDTotal'])?intval($dash_data['varFDTotal']):intval(0);?>,
                           <?php echo isset($dash_data['varCommodityTotal'])?intval($dash_data['varCommodityTotal']):intval(0);?>,
                           <?php echo isset($dash_data['varMFTotal'])?intval($dash_data['varMFTotal']):intval(0);?>,
                           <?php echo isset($dash_data['varInsuranceTotal'])?intval($dash_data['varInsuranceTotal']):intval(0);?>,
                           <?php echo isset($dash_data['varPropertyCurrent'])?intval($dash_data['varPropertyCurrent']):intval(0);?>
          ],
          backgroundColor: [
            "#F7464A",
            "#46BFBD",
            "#FDB45C",
            "#949FB1",
            "#4D5360",
            "#800080"
          ],
          label: 'Dataset 1'
        }],
        labels: [
          "Equity",
          "Fixed Deposit",
          "Commodity",
          "Mutual Funds",
          "Insurance",
          "Real Estate"
        ]
      },
      options: {
        responsive: true,
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Asset Allocation'
        },
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
      };
      var ctx = document.getElementById("myChart").getContext("2d");
      new Chart(ctx, config);
}



        // onload=init;

});
</script>
