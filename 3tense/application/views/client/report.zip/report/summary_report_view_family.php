<?php
if(isset($client_list))
{
$colorCodeArray =array(
          "#9B59B6","#E74C3C","#26B99A","#3498DB","#CFD4D8","#B370CF","#E95E4F","#36CAAB","#49A9EA","#FFFFFF",
          "#C0C0C0","#808080","#000000","#FF0000","#800000","#FFFF00","#808000","#00FF00","#008000","#00FFFF",
          "#008080","#0000FF","#000080","#FF00FF","#800080","#F0F8FF","#FAEBD7","#00FFFF","#7FFFD4","#F5F5DC",
          "#000000","#0000FF","#8A2BE2","#A52A2A","#DEB887","#5F9EA0","#7FFF00","#D2691E","#FF7F50","#6495ED",
          "#FFF8DC","#DC143C","#00FFFF","#00008B","#008B8B","#B8860B","#A9A9A9","#006400","#BDB76B","#556B2F",
          "#FF8C00","#8B0000","#E9967A","#8FBC8F","#483D8B","#2F4F4F","#00CED1","#FF1493","#696969","#1E90FF",
          "#FF69B4","#D3D3D3","#000080","#808000","#FF4500","#DA70D6","#DB7093","#DDA0DD","#CD853F","#FF0000",
          "#BC8F8F");
          $i=0;
          $total_cl_portfolio=0;
          $percentClient=array();
          $len=sizeof($client_list);
      foreach ($client_list as $rs)
      {
        $total_cl_portfolio=$total_cl_portfolio+intval($rs['TotalPortfolio']);
      }

      foreach ($client_list as $rs)
      {
          array_push($percentClient,((intval($rs['TotalPortfolio'])/$total_cl_portfolio)*100));

      }
       $labels = array();
       $datasets=array();
      foreach ($client_list as $rs)
      {
          array_push($labels,$rs['client_name']);
          array_push($datasets,intval($rs['TotalPortfolio']));
      }
} ?>
<?php
if(empty($summary_rep_data)) {
    echo "<script type='text/javascript'>
        alert('Unauthorized Access. Get Outta Here!');
        window.top.close();  //close the current tab
      </script>";
} else {
    $html = ''; //set html to blank
    $clientID = "";
    if(!empty($summary_rep_data)) {
        $familyID = $summary_rep_data[0]->family_id;
        $familyName = $summary_rep_data[0]->family_name;
    } else {
        $clientID = "";
        $clientName = "";
    }
    $css = '<style type="text/css">
                table { width:100% }
                body {color:black;}
                table td {font-size: 12px; padding:2px; text-align:center; }
                table th {font-size: 12px; padding:2px; text-align:center; border: 1px solid #4d4d4d;}
                .border {border: 1px solid #4d4d4d;}
                .amount { text-align:right;text-indent: 15px; }
                .noWrap { white-space: nowrap; }
                .title { line-height:28px; background-color: #f4a817; color: #000; font-size:15px; font-weight:bold; text-align:center; border:2px double #4d4d4d; }
                .info { font-size: 12px; font-weight: lighter; border:none; }
                .head-row { background-color: #4f8edc; color: #fff; font-weight:bold;}
                .normal {font-weight: normal;}
                .dataTotal {font-weight: bold; color:#4f8edc;}
                .no-border {border-width: 0px; border-color:#fff;}
                .client-name { text-align: left; font-size: 14px; font-weight: bold; }
                .bigger {font-weight: bold; font-size:14px;}
            </style>';
    $title = '<div class="title row">Summary Report of '.$familyName.'</div>
                    <br/>';
    if($summary_rep_data)
    {
        $htmlVal = '';
        $header = true;
        $content = false;
        $footer = false;
        $clientTotal = 0; //overall amount
        //family totals
        $famInsTotal = 0;
        $famFDTotal = 0;
        $famMFTotal = 0;
        $famEquityTotal = 0;
        $famRETotal = 0;
        $famCommodityTotal = 0;
        $familyTotal = 0;


        foreach($summary_rep_data as $row)
        {
            $clientTotal = round($row->insurance_inv + $row->fixed_deposit + $row->mutual_fund + $row->equity + $row->property + $row->commodity);
            if($header) {
                $htmlVal .= '<table border="0" cellpadding="4" style="text-align:center; border-width:0px;">
                    <tbody>
                        <tr nobr="true" class="head-row">
                            <th width="90">Client Name</th>
                            <th width="110">Insurance</th>
                            <th width="110">Fixed Income</th>
                            <th width="110">Mutual Funds</th>
                            <th width="110">Equity</th>
                            <th width="110">Real Estate</th>
                            <th width="110">Commodity</th>
                            <th width="120">Total Portfolio</th>
                            <th width="110">Life Cover</th>
                        </tr>
                    </tbody>';
                $header = false;
                $content = true;
            }

            if($content) {
                $htmlVal .= '<tr nobr="true">';
                        $htmlVal .= '<td class="border normal">'.$row->client_name.'</td>';

                        $ins = intval($row->insurance_inv);
                        $htmlVal .= !empty($ins)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->insurance_inv,0)).'</td>':'<td class="border normal"></td>';
                        // $htmlVal .= !empty($row->insurance_fund)?'<td>'.$this->common_lib->moneyFormatIndia(round($row->insurance_fund,2)).'</td>':'<td></td>';
                        $fd = intval($row->fixed_deposit);
                        $htmlVal .= !empty($fd)?'<td class="border  amount normal">'.$this->common_lib->moneyFormatIndia(round($row->fixed_deposit,0)).'</td>':'<td class="border normal"></td>';
                        $mf = intval($row->mutual_fund);
                        $htmlVal .= !empty($mf)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->mutual_fund,0)).'</td>':'<td class="border normal"></td>';
                        $eq = intval($row->equity);
                        $htmlVal .= !empty($eq)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->equity,0)).'</td>':'<td class="border normal"></td>';
                        $prop = intval($row->property);
                        $htmlVal .= !empty($prop)?'<td class="border  amount normal">'.$this->common_lib->moneyFormatIndia(round($row->property,0)).'</td>':'<td class="border normal"></td>';
                        $com = intval($row->commodity);
                        $htmlVal .= !empty($com)?'<td class="border  amount normal">'.$this->common_lib->moneyFormatIndia(round($row->commodity,0)).'</td>':'<td class="border normal"></td>';
                        $htmlVal .=  !empty($clientTotal)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($clientTotal,0)).'</td>':'<td class="border normal"></td>';
                        // $htmlVal .= '<td class="border">'.$this->common_lib->moneyFormatIndia($clientTotal).'</td>';

                $lc = intval($row->life_cover);
                $htmlVal .= !empty($lc)?'<td class="border amount normal">'.$this->common_lib->moneyFormatIndia(round($row->life_cover,0)).'</td>':'<td class="border normal"></td>';
                    $htmlVal .= '</tr>';

                $famInsTotal = round($famInsTotal + $row->insurance_inv);
                $famFDTotal = round($famFDTotal + $row->fixed_deposit);
                $famMFTotal = round($famMFTotal + $row->mutual_fund);
                $famEquityTotal = round($famEquityTotal + $row->equity);
                $famRETotal = round($famRETotal + $row->property);
                $famCommodityTotal = round($famCommodityTotal + $row->commodity);
                $familyTotal = round($familyTotal + $clientTotal);
            }
        }
        //footer with totals
        $htmlVal .= '<tr nobr="true">';
            $htmlVal .= '<td class="dataTotal border">Total</td>';
            $htmlVal .= !empty($famInsTotal)?'<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($famInsTotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= !empty($famFDTotal)?'<td class="dataTotal  amount border">'.$this->common_lib->moneyFormatIndia($famFDTotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= !empty($famMFTotal)?'<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($famMFTotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= !empty($famEquityTotal)?'<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($famEquityTotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= !empty($famRETotal)?'<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($famRETotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= !empty($famCommodityTotal)?'<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($famCommodityTotal).'</td>':'<td class="dataTotal border"></td>';
            $htmlVal .= '<td class="dataTotal amount border">'.$this->common_lib->moneyFormatIndia($familyTotal).'</td>';
            $htmlVal .= '<td class="border"></td>
                </tr>
        </table>';
    }
    $html .= $css;
    $html .= $htmlVal;
}
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.0/Chart.bundle.min.js'></script>
<div class="container" id="page-content" style="margin: 0; margin-top: -54px;" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
  <div>
    <input type="hidden" id="demo_id">
      <div id="page-heading">
            <div class="options">
                <div class="btn-toolbar">
                    <div class="btn-group">
                        <a href='#' class="btn btn-default dropdown-toggle" data-toggle='dropdown'><i class="fa fa-cloud-download"></i><span class="hidden-xs"> Export as  </span><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <?php $var=1;
                            $var=$var+1;?>
                            <li><a href="#" onclick="export_to_excel('<?php echo base_url('broker/Final_reports/export_to_excel');?>');">Excel File (*.xlsx)</a></li>
                            <li  id="l1"><a href="#" onclick="export_to_pdf('<?php echo base_url('client/Mutual_funds/export_to_pdf');?>');">PDF File (*.pdf)</a></li>
                            <li  id="l2"><a href="#" onclick="export_to_pdf('<?php echo base_url('client/Mutual_funds/export_to_pdf');?>');">PDF File (*.pdf)</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <form action="#" id="report_form" method="post" class="form-horizontal row-border">
                <div class="panel panel-midnightblue">
                    <div class="panel-gray panel-body collapse in panel-noborder">
                        <div id="css_data"><?php echo $css; ?></div>
                        <div class="rep-logo" style="margin-bottom: 120px;">
                            <?php if(!empty($logo)) { ?>
                                <img src="<?php echo base_url('uploads/brokers/'.$logo);?>" style="float: right; max-height: 80px;" />
                            <?php } ?>
                        </div>
                        <div id="title_data"><?php echo $title; ?></div>
                        <div class="row" id="report_data"  style="overflow-x : auto;"><?php echo $htmlVal; ?>
                        </br></br>
                          <table class="col-sm-12">
                            <tr>
                            <td>  <div id="canvas_img1" class="col-sm-6 col-md-6"></div> </td>
                            <td>  <div id="canvas_img2" class="col-sm-6 col-md-6"></div></td>
                            </tr>
                          </table>
                        </div>
                        <input type="hidden" name="logo" id="logo" value="<?php echo $logo;?>" />
                        <input type="hidden" name="name" id="name" value="<?php echo $familyName;?>" />
                        <input type="hidden" name="titleData" id="titleData" />
                        <input type="hidden" name="htmlData" id="htmlData" />
                        <input type="hidden" name="report_name" id="reportName" value="<?php echo $familyName;?> Family Summary Report" />
                    </div>
                </div>
            </form>
          </div>

      <!-- </div> -->

      <!-- Canvas 11 for canvas 2 image convert -->
      <!-- <div id="canvas_div">
        <div   class="col-md-4 col-xs-12">
        <div class="x_panel tile fixed_height_300">
          <div class="x_title">
            <h2 id="switchID">Asset Allocation</h2>
            <div class="clearfix"></div>
          </div>
          <div>
            <div class="x_content ">
                    <canvas id="canvas11"   height="200" width="200" style="margin: 15px 10px 10px 0"></canvas>
            </div>
          </div>
        </div>
      </div>
        <div   class="col-md-4  col-xs-12">
          <div class="x_panel tile fixed_height_300 fixed_width_300">
          <div class="x_title">
            <h2>Client Allocation</h2>
            <div class="clearfix"></div>
          </div>
          <div>
          <div class="x_content ">
                  <canvas id="canvas22" height="110" width="110" style="margin: 15px 10px 10px 0"></canvas>
          </div>
        </div>
        </div>
      </div>
     </div> -->

    </div>
  </div>
  </div>

<script>
      var canvas1,canvas2 ,ctx1,ctx2, bMouseIsDown = false, iLastX, iLastY,
          $save, $img1,$img2,
          $convert, $imgW, $imgH,
          $sel;
          $('#l2').hide();
          function init()
          {
              canvas1 = document.getElementById('canvas11');
              canvas2 = document.getElementById('canvas22');
              ctx1 = canvas1.getContext('2d');
              ctx2 = canvas2.getContext('2d');
              // $save = document.getElementById('save');
              // $convert = document.getElementById('convert');
              $sel = document.getElementById('sel');
              $img1 = document.getElementById('canvas_img1');
              $img2 = document.getElementById('canvas_img2');
              bind();
           }
          function bind ()
          {
                  var type = 'png',
                      w = 350,
                        h = 350;
                    $img1.append(Canvas2Image.convertToImage(canvas1, w, h, type))
                    $img2.append(Canvas2Image.convertToImage(canvas2, w, h, type))
                    $("#canvas_div").hide();
                    $("#l1").hide();
                    $("#l2").show();


          }
</script>

<script>
$(document).ready(function()
{

    Chart.defaults.doughnutLabels = Chart.helpers.clone(Chart.defaults.doughnut);
    var helpers = Chart.helpers;
    var defaults = Chart.defaults;
    Chart.controllers.doughnutLabels = Chart.controllers.doughnut.extend({
    	updateElement: function(arc, index, reset) {
        var _this = this;
        var chart = _this.chart,
            chartArea = chart.chartArea,
            opts = chart.options,
            animationOpts = opts.animation,
            arcOpts = opts.elements.arc,
            centerX = (chartArea.left + chartArea.right) / 2,
            centerY = (chartArea.top + chartArea.bottom) / 2,
            startAngle = opts.rotation, // non reset case handled later
            endAngle = opts.rotation, // non reset case handled later
            dataset = _this.getDataset(),
            circumference = reset && animationOpts.animateRotate ? 0 : arc.hidden ? 0 : _this.calculateCircumference(dataset.data[index]) * (opts.circumference / (2.0 * Math.PI)),
            innerRadius = reset && animationOpts.animateScale ? 0 : _this.innerRadius,
            outerRadius = reset && animationOpts.animateScale ? 0 : _this.outerRadius,
            custom = arc.custom || {},
            valueAtIndexOrDefault = helpers.getValueAtIndexOrDefault;

        helpers.extend(arc, {
          // Utility
          _datasetIndex: _this.index,
          _index: index,

          // Desired view properties
          _model: {
            x: centerX + chart.offsetX,
            y: centerY + chart.offsetY,
            startAngle: startAngle,
            endAngle: endAngle,
            circumference: circumference,
            outerRadius: outerRadius,
            innerRadius: innerRadius,
            label: valueAtIndexOrDefault(dataset.label, index, chart.data.labels[index])
          },

          draw: function () {
          	var ctx = this._chart.ctx,
    						vm = this._view,
    						sA = vm.startAngle,
    						eA = vm.endAngle,
    						opts = this._chart.config.options;

    					var labelPos = this.tooltipPosition();
    					var segmentLabel = vm.circumference / opts.circumference * 100;

    					ctx.beginPath();

    					ctx.arc(vm.x, vm.y, vm.outerRadius, sA, eA);
    					ctx.arc(vm.x, vm.y, vm.innerRadius, eA, sA, true);

    					ctx.closePath();
    					ctx.strokeStyle = vm.borderColor;
    					ctx.lineWidth = vm.borderWidth;

    					ctx.fillStyle = vm.backgroundColor;

    					ctx.fill();
    					ctx.lineJoin = 'bevel';

    					if (vm.borderWidth) {
    						ctx.stroke();
    					}

    					if (vm.circumference > 0.15) { // Trying to hide label when it doesn't fit in segment
    						ctx.beginPath();
    						ctx.font = helpers.fontString(opts.defaultFontSize, opts.defaultFontStyle, opts.defaultFontFamily);
    						ctx.fillStyle = "#fff";
    						ctx.textBaseline = "top";
    						ctx.textAlign = "center";

                // Round percentage in a way that it always adds up to 100%
    						ctx.fillText(segmentLabel.toFixed(0) + "%", labelPos.x, labelPos.y);
    					}
          }
        });

        var model = arc._model;
        model.backgroundColor = custom.backgroundColor ? custom.backgroundColor : valueAtIndexOrDefault(dataset.backgroundColor, index, arcOpts.backgroundColor);
        model.hoverBackgroundColor = custom.hoverBackgroundColor ? custom.hoverBackgroundColor : valueAtIndexOrDefault(dataset.hoverBackgroundColor, index, arcOpts.hoverBackgroundColor);
        model.borderWidth = custom.borderWidth ? custom.borderWidth : valueAtIndexOrDefault(dataset.borderWidth, index, arcOpts.borderWidth);
        model.borderColor = custom.borderColor ? custom.borderColor : valueAtIndexOrDefault(dataset.borderColor, index, arcOpts.borderColor);

        // Set correct angles if not resetting
        if (!reset || !animationOpts.animateRotate) {
          if (index === 0) {
            model.startAngle = opts.rotation;
          } else {
            model.startAngle = _this.getMeta().data[index - 1]._model.endAngle;
          }

          model.endAngle = model.startAngle + model.circumference;
        }

        arc.pivot();
      }
    });
      var config = {
      type: 'doughnutLabels',
      data: {
        datasets: [{
          data: [<?php echo isset($dash_data['varTotalEquityPortfolio'])?intval($dash_data['varTotalEquityPortfolio']):intval(0);?>,
          <?php echo isset($dash_data['varFDTotal'])?intval($dash_data['varFDTotal']):intval(0);?>,
          <?php echo isset($dash_data['varCommodityTotal'])?intval($dash_data['varCommodityTotal']):intval(0);?>,
          <?php echo isset($dash_data['varMFTotal'])?intval($dash_data['varMFTotal']):intval(0);?>,
          <?php echo isset($dash_data['varInsuranceTotal'])?intval($dash_data['varInsuranceTotal']):intval(0);?>,
          <?php echo isset($dash_data['varPropertyCurrent'])?intval($dash_data['varPropertyCurrent']):intval(0);?>
            ],
          backgroundColor: [
            "#F7464A",
            "#46BFBD",
            "#FDB45C",
            "#949FB1",
            "#4D5360",
            "#800080"
          ],
          label: 'Dataset 1'
        }],
        labels: [
          "Equity",
          "Fixed Deposit",
          "Commodity",
          "Mutual Funds",
          "Insurance",
          "Real Estate"
        ]
      },
      options: {
        responsive: true,
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Asset Allocation'
        },
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
    };
    var ctx = document.getElementById("canvas11").getContext("2d");
    new Chart(ctx, config);
});
</script>
<script>
$(document).ready(function()
{
  var colorCodeArray =<?php echo json_encode($colorCodeArray);?> ;
  var labels =<?php echo json_encode($labels);?>;
  var datasets =<?php echo json_encode($datasets); ?>;
    Chart.defaults.doughnutLabels = Chart.helpers.clone(Chart.defaults.doughnut);
    var helpers = Chart.helpers;
    var defaults = Chart.defaults;
    Chart.controllers.doughnutLabels = Chart.controllers.doughnut.extend({
    	updateElement: function(arc, index, reset) {
        var _this = this;
        var chart = _this.chart,
            chartArea = chart.chartArea,
            opts = chart.options,
            animationOpts = opts.animation,
            arcOpts = opts.elements.arc,
            centerX = (chartArea.left + chartArea.right) / 2,
            centerY = (chartArea.top + chartArea.bottom) / 2,
            startAngle = opts.rotation, // non reset case handled later
            endAngle = opts.rotation, // non reset case handled later
            dataset = _this.getDataset(),
            circumference = reset && animationOpts.animateRotate ? 0 : arc.hidden ? 0 : _this.calculateCircumference(dataset.data[index]) * (opts.circumference / (2.0 * Math.PI)),
            innerRadius = reset && animationOpts.animateScale ? 0 : _this.innerRadius,
            outerRadius = reset && animationOpts.animateScale ? 0 : _this.outerRadius,
            custom = arc.custom || {},
            valueAtIndexOrDefault = helpers.getValueAtIndexOrDefault;

        helpers.extend(arc, {
          // Utility
          _datasetIndex: _this.index,
          _index: index,

          // Desired view properties
          _model: {
            x: centerX + chart.offsetX,
            y: centerY + chart.offsetY,
            startAngle: startAngle,
            endAngle: endAngle,
            circumference: circumference,
            outerRadius: outerRadius,
            innerRadius: innerRadius,
            label: valueAtIndexOrDefault(dataset.label, index, chart.data.labels[index])
          },

          draw: function () {
          	var ctx = this._chart.ctx,
    						vm = this._view,
    						sA = vm.startAngle,
    						eA = vm.endAngle,
    						opts = this._chart.config.options;

    					var labelPos = this.tooltipPosition();
    					var segmentLabel = vm.circumference / opts.circumference * 100;

    					ctx.beginPath();

    					ctx.arc(vm.x, vm.y, vm.outerRadius, sA, eA);
    					ctx.arc(vm.x, vm.y, vm.innerRadius, eA, sA, true);

    					ctx.closePath();
    					ctx.strokeStyle = vm.borderColor;
    					ctx.lineWidth = vm.borderWidth;

    					ctx.fillStyle = vm.backgroundColor;

    					ctx.fill();
    					ctx.lineJoin = 'bevel';

    					if (vm.borderWidth) {
    						ctx.stroke();
    					}

    					if (vm.circumference > 0.15) { // Trying to hide label when it doesn't fit in segment
    						ctx.beginPath();
    						ctx.font = helpers.fontString(opts.defaultFontSize, opts.defaultFontStyle, opts.defaultFontFamily);
    						ctx.fillStyle = "#fff";
    						ctx.textBaseline = "top";
    						ctx.textAlign = "center";

                // Round percentage in a way that it always adds up to 100%
    						ctx.fillText(segmentLabel.toFixed(0) + "%", labelPos.x, labelPos.y);
    					}
          }
        });

        var model = arc._model;
        model.backgroundColor = custom.backgroundColor ? custom.backgroundColor : valueAtIndexOrDefault(dataset.backgroundColor, index, arcOpts.backgroundColor);
        model.hoverBackgroundColor = custom.hoverBackgroundColor ? custom.hoverBackgroundColor : valueAtIndexOrDefault(dataset.hoverBackgroundColor, index, arcOpts.hoverBackgroundColor);
        model.borderWidth = custom.borderWidth ? custom.borderWidth : valueAtIndexOrDefault(dataset.borderWidth, index, arcOpts.borderWidth);
        model.borderColor = custom.borderColor ? custom.borderColor : valueAtIndexOrDefault(dataset.borderColor, index, arcOpts.borderColor);

        // Set correct angles if not resetting
        if (!reset || !animationOpts.animateRotate) {
          if (index === 0) {
            model.startAngle = opts.rotation;
          } else {
            model.startAngle = _this.getMeta().data[index - 1]._model.endAngle;
          }

          model.endAngle = model.startAngle + model.circumference;
        }

        arc.pivot();
      }
    });
      var config = {
      type: 'doughnutLabels',
      data: {
        datasets: [{
          data:datasets,
          backgroundColor:colorCodeArray,
          label: 'Dataset 1'
        }],
        labels: labels,
      },
      options: {
        responsive: true,
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Client Allocation'
        },
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
    };
    var ctx = document.getElementById("canvas22").getContext("2d");
    new Chart(ctx, config);
});
</script>
